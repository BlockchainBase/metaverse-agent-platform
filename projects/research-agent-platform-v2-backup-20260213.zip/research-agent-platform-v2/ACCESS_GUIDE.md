# 🚀 本地访问指南

## 服务状态

| 服务 | 地址 | 状态 |
|-----|------|------|
| 后端API | http://localhost:9876 | ✅ 运行中 |
| 前端 | http://localhost:5173 | ✅ 运行中 |

## 访问方式

### 1. 浏览器直接访问
```
http://localhost:5173
```

### 2. 如果localhost不行，尝试
```
http://127.0.0.1:5173
```

### 3. 查看本机IP
```bash
ifconfig | grep "inet " | head -3
```
然后用IP访问：
```
http://<你的IP>:5173
```

## 常见问题

### 问题1：端口被占用
**解决**：修改vite.config.ts里的port

### 问题2：防火墙阻止
**解决**：Mac系统设置 → 安全性与隐私 → 防火墙 → 关闭或允许

### 问题3：网络代理问题
**解决**：浏览器关闭代理，或添加localhost到白名单

## 快速重启

如果还是访问不了，重启服务：

```bash
# 1. 重启后端
cd ~/.openclaw/workspace/projects/research-agent-platform-v2/src/backend
pkill -f "server-simple.js"
node server-simple.js

# 2. 重启前端（新终端）
cd ~/.openclaw/workspace/projects/research-agent-platform-v2/src/frontend
npm run dev -- --host
```

**注意**：加 `--host` 参数允许外部访问

## 检查命令

```bash
# 检查端口占用
lsof -i :5173
lsof -i :9876

# 检查服务进程
ps aux | grep node
```
