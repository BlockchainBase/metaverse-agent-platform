import { Router } from 'express';
export declare function setupRoutes(app: Router): void;
